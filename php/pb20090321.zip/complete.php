<html>
<head>
<title>会員登録</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
</head>
<sdfghjkbody>
<?php
// ここに会員登録処理を記述
//var_dump($_POST); // 送信データの確認

//
// 登録情報をファイルに書き込む
//
$name     = $_POST["name"];
$email    = $_POST["email"];
$user_id  = $_POST["user_id"];
$password = $_POST["password"];
$gender   = $_POST["gender"];
$address  = $_POST["address"];
$course   = $_POST["course"];
$pr       = $_POST["pr"];

$file_name = "members.dat";
$fp = fopen ($file_name, "a"); // 追加書き込みモードで開く (書き込み先ディレクトリのパーミッションを第三者書込可にしておくこと）
if (!$fp) {
	die("ファイルのオープンに失敗しました");
}

// !! 追加処理 !!
// $courseは配列なのでそのままでは書き出せない。
// implode()関数を使って「:」区切りの文字列に変換しておく。
//
$courses = implode(":", $course);

fputs ($fp, "$name,$email,$user_id,$password,$gender,$address,$courses,$pr\n"); // $course --> $cousesに変更
fclose($fp);

$subject = "会員登録の確認";
$body = <<<EOF
{$name}様

この度は当サイトへの登録ありがとうございました。
登録情報は以下の通りです。

ユーザID：$user_id;
パスワード：$password;
EOF;

$from = "From:phpbasic@la.jp";
mb_language("ja");
mb_internal_encoding("UTF-8");
if(!mb_send_mail($email, $subject, $body, $from)) {
	die("メールの送信に失敗しました");
}

?>
<h1>登録完了</h1>
会員登録を完了しました。トップページからユーザIDとパスワードでログインしてください。<br>
<a href="index.html">トップページへ</a>
</body>
