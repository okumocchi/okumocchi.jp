<html>
<head>
<title>会員登録</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
</head>
<body>
<h1>入力内容確認</h1>
<?php
// 変換用配列を用意
$gender_list = array(0=>"", "m"=>"男", "f"=>"女");
$address_list = array(1=>"東京都", 2=>"神奈川県", 3=>"千葉県", 4=>"埼玉県");
$course_list = array(1=>"PHPベーシック", 2=>"PHPマスター", 3=>"システム開発演習", 4=>"資格対策");

// 入力されたデータの取得
$name     = $_POST["name"];
$email    = $_POST["email"];
$user_id  = $_POST["user_id"];
$password = $_POST["password"];
if (isset($_POST["gender"])) {
    $gender   = $_POST["gender"];
} else {
	$gender = 0;
}
$address  = $_POST["address"];
if (isset($_POST["course"])) {
    $course   = $_POST["course"];
} else {
	$course = array(); //空の配列で初期化
}
$pr       = $_POST["pr"];

//
// トリミング
$name = preg_replace('/^[\s　]*(.*?)[\s　]*$/u', '$1', $name);
$user_id = preg_replace('/^[\s　]*(.*?)[\s　]*$/u', '$1', $user_id);
$password = preg_replace('/^[\s　]*(.*?)[\s　]*$/u', '$1', $password);

//
// 入力値チェック
//
$error_flag = false; // エラーフラグ
if (empty($name)) {
	echo "<div style='color:red'>氏名が入力されていません</div>";
	$error_flag = true; // エラーフラグを立てる
}
if (empty($email)) {
	echo "<div style='color:red'>メールアドレスが入力されていません</div>";
	$error_flag = true; // エラーフラグを立てる
} elseif (!preg_match('|^[a-z0-9_.~?/-]+@([a-z0-9-]+\.)+[a-z0-9-]+$|i', $email)) {
	echo "<div style='color:red'>正しいメールアドレスではありません</div>";
	$error_flag = true; // エラーフラグを立てる
}
if (empty($user_id)) {
	echo "<div style='color:red'>ユーザIDが入力されていません</div>";
	$error_flag = true; // エラーフラグを立てる
} elseif (strlen($user_id) > 10 ) {
	echo "<div style='color:red'>ユーザIDは10文字以下で入力してください</div>";
	$error_flag = true; // エラーフラグを立てる
} elseif (!preg_match('/^\w+$/', $user_id)) {
	echo "<div style='color:red'>ユーザIDに使用できない文字が含まれています</div>";
	$error_flag = true; // エラーフラグを立てる
}
if (empty($password)) {
	echo "<div style='color:red'>パスワードが入力されていません</div>";
	$error_flag = true; // エラーフラグを立てる
} elseif (strlen($password) < 6 ||  strlen($password) > 20) {
	echo "<div style='color:red'>パスワードは6文字以上20文字以下で入力してください</div>";
	$error_flag = true; // エラーフラグを立てる
} elseif (!preg_match('/^[!-~]+$/', $password)) {
	echo "<div style='color:red'>パスワードに使用できない文字が含まれています</div>";
	$error_flag = true; // エラーフラグを立てる
}
if (empty($gender)) {
	echo "<div style='color:red'>性別が選択されていません</div>";
	$error_flag = true; // エラーフラグを立てる
}
if (empty($course)) {
	echo "<div style='color:red'>コースが選択されていません</div>";
	$error_flag = true; // エラーフラグを立てる
}
if (empty($pr)) {
	echo "<div style='color:red'>自己PRが入力されていません</div>";
	$error_flag = true; // エラーフラグを立てる
}

if ($error_flag) {
  // !! 追加処理 !!
  // 入力エラーが１つでもあったときの処理
  //
?>
<form action="confirm.php" method="POST">
<table border="1">
<tr><th>氏名</th><td><input type="text" name="name" value="<?php echo $name ?>"></td></tr>
<tr><th>メールアドレス</th><td><input type="text" name="email" value="<?php echo $email ?>"></td>
</tr><tr><th>ユーザID</th><td><input type="text" name="user_id" value="<?php echo $user_id ?>"></td></tr>
<tr><th>パスワード</th><td><input type="text" name="password" value="<?php echo $password ?>"></td></tr>
<tr><th>性別</th><td>
<input type="radio" name="gender" value="m"<?php if ($gender == "m") echo " checked" ?>>男
<input type="radio" name="gender" value="f"<?php if ($gender == "f") echo " checked" ?>>女
</td></tr>
<tr><th>住所</th><td>
<select name="address">
  <option value="1"<?php if ($address == "1") echo " selected" ?>>東京都</option>
  <option value="2"<?php if ($address == "2") echo " selected" ?>>神奈川県</option>
  <option value="3"<?php if ($address == "3") echo " selected" ?>>千葉県</option>
  <option value="4"<?php if ($address == "4") echo " selected" ?>>埼玉県</option>
</select>
</td></tr>
<tr><th>コース</th><td>
<input type="checkbox" name="course[]" value="1"<?php if (in_array("1", $course)) echo " checked" ?>>PHPベーシック<br>
<input type="checkbox" name="course[]" value="2"<?php if (in_array("2", $course)) echo " checked" ?>>PHPマスター<br>
<input type="checkbox" name="course[]" value="3"<?php if (in_array("3", $course)) echo " checked" ?>>システム開発演習<br>
<input type="checkbox" name="course[]" value="4"<?php if (in_array("4", $course)) echo " checked" ?>>資格対策<br>
</td></tr>
<tr><th>自己PR</th><td><textarea name="pr" rows="4" cols="25"><?php echo $pr ?></textarea></td></tr>
</table>
<input type="submit" value="送信">
</form>
<?php
} else {
?>
以下の内容で正しければ[送信]ボタンをクリックしてください。<br>
修正する場合は[戻る]ボタンをクリックしてください。<br>
<table border="1">
<tr><th>氏名</th><td><?php echo $name ?></td></tr>
<tr><th>メールアドレス</th><td><?php echo $email ?></td></tr>
<tr><th>ユーザID</th><td><?php echo $user_id ?></td></tr>
<tr><th>パスワード</th><td><?php echo $password ?></td></tr>
<tr><th>性別</th><td><?php echo $gender_list[$gender] ?></td></tr>
<tr><th>住所</th><td><?php echo $address_list[$address] ?></td></tr>
<tr><th>コース</th><td>
<?php
foreach ($course as $code) {
    echo $course_list[$code] . "<br>";
}
?>
</td></tr>
<tr><th>自己PR</th><td><?php echo nl2br($pr) ?></td></tr>
</table>

<form action="complete.php" method="POST">
<input type="hidden" name="name" value="<?php echo $name ?>">
<input type="hidden" name="email" value="<?php echo $email ?>">
<input type="hidden" name="user_id" value="<?php echo $user_id ?>">
<input type="hidden" name="password" value="<?php echo $password ?>">
<input type="hidden" name="gender" value="<?php echo $gender ?>">
<input type="hidden" name="address" value="<?php echo $address ?>">
<?php
foreach ($course as $code) {
  echo '<input type="hidden" name="course[]" value="' . $code . '">';
}
?>
<input type="hidden" name="pr" value="<?php echo $pr ?>">
<input type="submit" value="送信">
<input type="button" value="戻る" onClick="javascript:history.back()">
</form>
<?php
}
?>

</body>
</html>





