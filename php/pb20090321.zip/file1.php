<html>
<body>
<?php
$fp = fopen("members.dat", "r");
while (!feof($fp)) {
	echo fgets($fp);
	echo "<br>";
}
fclose($fp);
?>
</body>
</html>

