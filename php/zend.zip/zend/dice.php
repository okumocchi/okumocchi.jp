<?php
class Dice {
    private $num;
    
    public function __construct() {
        $this->cast();
    }
    public function cast() {
        $this->num = mt_rand(1, 6);
    }
    public function getNum() {
        return $this->num;
    }
}


$dice = new Dice();
echo $dice->getNum();

$dice->cast();
echo $dice->getNum();

?>