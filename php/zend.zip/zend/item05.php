<?php
// item05.php
//
// Itemクラスを継承して、Clothes（衣料品）クラスを定義する。
// ■新しく「size」プロパティを追加する
// ■以下のように出力する
//
//  ウールハット(M)　\15000
// <<< images/hat.jpg >>> (画像を表示）
// ----------------------------------------- (水平線)
//  デニムパンツ(L) \20000
// <<< images/denim.jpg >>> (画像を表示）
//


class Item {
    private $name;
    private $price;
    private $img;
    
    public function __construct($name, $price, $img) {
        $this->name = $name;
        $this->price  = $price;
        $this->img = $img;
    }
    public function getName() {
        return $this->name;
    }
    public function getPrice() {
        return $this->price;
    }
    public function getImg() {
        return $this->img;
    }
}

class Clothes extends Item {
    private $size;
    
    public function __construct($name, $price, $size, $img) {
        $this->size = $size;
        parent::__construct($name, $price, $img);
    }
    public function getName() {
        return parent::getName() . "("  . $this->size . ")";
    }
}    

$item1 = new Clothes("ウールハット", 15000, "M", "hat.jpg");
$item2 = new Clothes("デニムパンツ", 20000, "L", "denim.jpg");

showItem($item1);
echo "<hr>";
showItem($item2);

$item3 = new Item("ボールペン", 500, "pen.jpg");
echo "<hr>";
showItem($item3);


function showItem(Item $item) {
  echo $item->getName() . "　" . "&yen;" . number_format($item->getPrice());
  echo "<br>";
  echo '<img src="images/' . $item->getImg() . '">';
}



?>