<?php
/*
$name1 = "ウールハット";
$price1 = 15000;
$color1 = "黒";
$img1 = "hat.jpg";

$name2 = "デニムパンツ";
$price2 = 20000;
$img2 = "denim.jpg";

//echo $name1 . "(" . $color1 . ")" . " &yen;" . $price1 . "<br>";
echo "$name1($color1) &yen;$price1<br>";
echo "<img src=\"images/$img1\">";

echo "<hr>";
 
echo $name2 . " &yen;" . $price2 . "<br>";
echo "<img src=\"images/" . $img2 . "\">";
*/

$name[0] = "ウールハット";
$price[0] = 15000;
$color[0] = "黒";
$img[0] = "hat.jpg";

$name[1] = "デニムパンツ";
$price[1] = 20000;
$img[1] = "denim.jpg";

/*
echo "$name[0]($color[0]) &yen;$price[0]<br>";
echo "<img src=\"images/$img[0]\">";
echo "<hr>";
echo $name[1] . " &yen;" . $price[1] . "<br>";
echo "<img src=\"images/" . $img[1] . "\">";
*/

for ($i = 0; $i < 2; $i++) {
    echo "$name[$i]";
    if ($color[$i]) {
      echo "($color[$i])";
    }
    echo "&yen;$price[$i]<br>";
    echo "<img src=\"images/$img[$i]\">";
    echo "<hr>";
}

?>
















/*
//
// 商品クラス
//
class Item {
    var $name;
    var $price;
    var $color;
    var $img;
}
*/


/*
class Item {
    private $name;
    private $price;
    
    public function __constructor($name, $price) {
        $this->name = $name;
        $this->price = $price;
    }
}
*/  