<?php
	$arr = array( 1, 10, 49, 49=>10, "Dog");
	$arr[] = "Cat";
	$arr[10] = "Monkey";
	$arr[] = "Mouse";
	print( $arr[$arr[$arr[2]]]);
?>
