<?php
	class MyClass {
		private $name;
		private function __construct($name) {
			$this->name = $name;
		}
		public static function getInstance($name) {
			return new MyClass($name);
		}
		
		public function showName() {
			print($this->name);
		}
	}
	
	$obj1 = MyClass::getInstance("Taro");
	$obj1->showName();
?>
