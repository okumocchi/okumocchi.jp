<?php
	print(date("Y-m-d H:i:s", strtotime("10 September 2000")));
?>
