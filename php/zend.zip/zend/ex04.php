<?php
	$arr = array( 1, 10, 100, "ABC", "DEF");
	$arr[] = 1000;
	$arr[] = "GHI";
	
	print $arr[5];
?>