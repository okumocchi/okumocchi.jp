<?php
	class Cart {
		public $items;
		public $item;
		
		function __construct() {
			$this->items = 0;
			$this->item = array();
		}
		
		function add($name) {
			$this->items++;
			$this->item[] = $name;
		}
		
	}
	
	$c1 = new Cart;
	$c2 = new Cart;
	$c1->add("Pen");
	print($c2->item[$c1->items]);
?>
