<?php
	class MyClass {
		private $name;
		private function __construct($name) {
			$this->name = $name;
		}
		
		final public function showName() {
			print($this->name);
		}
	}
	
	final class bar1 extends MyClass {}
	
	class bar2 extends MyClass {
		function showName() {
			print("No name...");
		}
	}
	
	$b1 = new bar1();
	$b1->showName();
?>
