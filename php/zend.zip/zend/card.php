<?php
class Card {
    private $mark; // spade 1 heart 2 dia 3 club 4
    private $num;
    public static $marks = array(1=>"S", 2=>"H", 3=>"D", 4=>"C");
    public static $nums = array(1=>" A", 2=>" 2", 3=>" 3", 4=>" 4", 5=>" 5", 6=>" 6",  
           7=>" 7", 8=>" 8", 9=>" 9", 10=>"10", 11=>" J", 12=>" Q", 13=>" K");

    
    
    public function __construct($mark, $num) {
        $this->mark = $mark;
        $this->num = $num;
    }
    
    public function __toString() {
       return "[" . self::$marks[$this->mark] . self::$nums[$this->num] . "]";
    }
}


$card1 = new Card(1,1);
echo $card1;

echo Card::$marks[1];
?>