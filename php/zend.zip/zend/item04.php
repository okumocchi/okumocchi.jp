<?php
// item04.php
//
// item03.phpを以下の通りに修正する。
// ■Itemクラスのすべてのプロパティをprivateとし、カプセル化する。
// ■Itemクラスにコンストラクタを定義する。
// ■Itemクラスのプロパティを取得するための以下のゲッタメソッドを定義する。
//   getName(), getPrice(), getImg()
//


?>