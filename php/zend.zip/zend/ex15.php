<?php
	$strs = array(
		"http://www.linuxacademy.ne.jp",
		"info@linuxacademy.ne.jp",
		"info@php.net",
		"007@php.net",
		"www.example.com"
	);
	
	foreach($strs as $str) {
		if (preg_match("/[a-z]+@[a-z]+\.[a-z]{3}/", $str)) {
			echo "$str<br>";
		}
	}
?>
