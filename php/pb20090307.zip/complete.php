<html>
<head>
<title>会員登録</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
</head>
<body>
<?php
// ここに会員登録処理を記述
?>
<h1>登録完了</h1>
会員登録を完了しました。トップページからユーザIDとパスワードでログインしてください。<br>
<a href="index.html">トップページへ</a>
</body>

