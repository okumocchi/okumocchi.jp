<html>
<head>
<title>会員登録</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
</head>
<body>
<h1>入力内容確認</h1>
以下の内容で正しければ[送信]ボタンをクリックしてください。<br>
修正する場合は[戻る]ボタンをクリックしてください。<br>
<?php
// 変換用配列を用意
$gender_list  = array("m"=>"男", "f"=>"女");
$address_list = array(1=>"東京都", 2=>"神奈川県", 3=>"千葉県", 4=>"埼玉県");
$course_list  = array(1=>"PHPベーシック", 2=>"PHPマスター", 3=>"システム開発演習", 4=>"資格対策");

// 入力されたデータの取得
$name     = $_POST["name"];			// 入力された値そのものが渡される
$email    = $_POST["email"];		// 同上
$user_id  = $_POST["user_id"];		// 同上
$password = $_POST["password"];		// 同上
$gender   = $_POST["gender"];		// 性別コードで渡される
$address  = $_POST["address"];		// 都道府県コードが渡される
$course   = $_POST["course"];     	// コースコードが配列で渡される
$pr       = $_POST["pr"];			// 入力された値そのものが渡される
?>

//
// 入力データを表組みで出力
// ＊氏名、メールアドレス、ユーザID、パスワードは入力値をそのまま出力
// ＊性別、住所はコードを変換用の配列を用い値に変換して出力
// ＊コースはforeach文でコードを１つずつ取り出し、変換用の配列を用い値に変換して出力
// ＊自己PRは入力された値をnl2br()関数に渡し、改行コードを<br>タグに変換された戻り値の文字列を出力
//
<table border="1">
<tr><th>氏名</th><td><?php echo $name ?></td></tr>
<tr><th>メールアドレス</th><td><?php echo $email ?></td></tr>
<tr><th>ユーザID</th><td><?php echo $user_id ?></td></tr>
<tr><th>パスワード</th><td><?php echo $password ?></td></tr>
<tr><th>性別</th><td><?php echo $gender_list[$gender] ?></td></tr>
<tr><th>住所</th><td><?php echo $address_list[$address] ?></td></tr>
<tr><th>コース</th><td>
<?php
foreach ($course as $code) {
  echo $course_list[$code] . "<br>";
}
?>
</td></tr>
<tr><th>自己PR</th><td><?php echo nl2br($pr) ?></td></tr>
</table>

<form action="complete.php" method="POST">
<input type="submit" value="送信">
<input type="button" value="戻る" onClick="javascript:history.back()">
</form>
</body>
