<?php

$y = 2009;
$m = 2;
$d = 29;

if(checkdate($m, $d, $y)) {  // if (checkdate($m, $d, $y) == true) と同じ
	echo "有効な日付です。";
} else {
	echo "無効な日付です。";
}
?>

