<?php
//
// 関数の定義
//

// 自分の名前を出力する関数(引数、戻り値ともになし）
function myname() {
	echo "LA Taro<br>";
}
// 自分の名前を戻り値として返す関数（引数はなし）
function myname2() {
	return "LA Taro<br>";
}
// 色指定のタグを伴った文字列を返す関数（色名を引数にとる）
function myname3($col) {
	return "<span style='color:{$col};'>LA Taro</span><br>";
}
// 色と文字サイズを指定するタグを伴った文字列を返す関数（色名と文字サイズを引数にとる）
function myname4($col, $size) {
	return "<span style='color:{$col};font-size:{$size}'>LA Taro</span><br>";
}


//
// メイン処理
//
// 関数の呼び出し
myname();
echo myname2();
echo myname3("blue");
echo myname3("gray");
echo myname3("#55AAFF");

// 繰り返しの中で関数を呼ぶと・・・
for ($i = 10; $i <= 50; $i++) {
  echo myname4("green", $i);
}
?>

