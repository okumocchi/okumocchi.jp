<?php
$ten = 50;

if($ten >= 80){
	echo "優";
} elseif($ten >= 60){
	echo "良";
} elseif($ten >= 40){
	echo "可";
} else {
	echo "不可";
} 
