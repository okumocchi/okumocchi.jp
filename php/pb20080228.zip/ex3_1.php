<?php
$ten = 85;

if ($ten >= 80) {
   echo "合格！";
} else {
   echo "追試です";
}
?>
