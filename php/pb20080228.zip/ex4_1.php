<?php
$blood = "A";

switch ($blood ) {
case "A":
	echo "几帳面?";
    break;
case "B":
	echo "マイペース？";
    break;
case "AB":
	echo "独創的？";
    break;
case "O" :
	echo "大らか？";
    break;
default:
	echo "判定不能";
	break;
}

/*
// 小文字での判別も可能にしたバージョン

switch ($blood ) {
case "A":
case "a":
	echo "几帳面?";
    break;
case "B":
case "b":
	echo "マイペース？";
    break;
case "AB":
case "ab":
	echo "独創的？";
    break;
case "O" :
case "o":
	echo "大らか？";
    break;
default:
	echo "判定不能";
	break;
}

*/

?>

