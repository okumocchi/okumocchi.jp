<?php
//
// デザイン（HTML）とロジック（PHP）が一体となった例
//

$name = "山田 太郎";
$gender = 1;
?>

<html>
<body>
<?php echo $name ?>さん(
<?php
if ($gender == 1) {
	echo "男";
} elseif ($gender == 2) {
	echo "女";
} else {
	echo "不明";
}
?>)<br>
</body>
</html>

