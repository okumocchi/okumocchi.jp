<?php
//
// ロジックの実装
//

// Smartyクラスの定義ファイルの読み込み
require_once "/usr/share/Smarty/libs/Smarty.class.php";

// Smartyクラスのオブジェクトを作成
$tpl = new Smarty;

$name = "山田太郎";
$gender = 1;

// Smarty変数に値をセット
$tpl->assign("name", $name);
$tpl->assign("gender", $gender);

// テンプレートファイルを指定してHTML出力を行う
$tpl->display("smarty.tpl");
?>
