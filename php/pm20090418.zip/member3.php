<?php
class Member {
  // プロパティの宣言	
  private $name;
  private $birthday;

  // コンストラクタの定義
  // オブジェクトの作成時に自動的に呼ばれる特殊なメソッド
  public function __construct($name, $birthday) {
	  $this->name = $name;
	  $this->birthday = $birthday;
  }

  // メソッドの定義
  public function getAge() {
	$age = floor((date("Ymd") - date("Ymd", strtotime($this->birthday))) /10000);
	return $age;
  }
  public function setName($name) {
	  $this->name = $name;
  }
  public function setBirthday($birthday) {
    $this->birthday = $birthday;
  }
  public function getName() {
    return $this->name;	
  }

  // 静的なメソッドの定義（オブジェクトに依存しない処理のみ記述）
  public static function hello() {
	  echo "Hello";
  }
}

// 引数付きでオブジェクトを作成（コンストラクタに渡される）
$m1 = new Member("鈴木一朗", "1973-10-22");
echo $m1->getName() . "さんは現在" . $m1->getAge() . "歳です<br>";

$m2 = new Member("浅田真央","1990-9-25");
echo $m2->getName() . "さんは現在" . $m2->getAge() . "歳です<br>";

// クラスを指定して静的メソッドを呼び出す
Member::hello();
// オブジェクトからでも静的メソッドが呼び出せる
$m1->hello();

// 静的でないメソッドをクラスからは呼び出せない
Member::setName("麻生太郎"); // <--- エラー！

?>

