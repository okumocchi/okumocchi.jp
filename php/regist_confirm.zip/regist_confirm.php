<?php
//
// regist_confirm.php
//

require "/usr/share/Smarty/libs/Smarty.class.php";
$tpl = new Smarty;

// エラーフラグ
$errorFlag = false;

// フォーム入力データの取得と入力値チェック
$userID = $_POST["userID"];
if (empty($userID)) {
  $tpl->assign("error_no_id", 1); 
  $errorFlag = true;
}

$password = $_POST["password"];
if (empty($password)) {
  $tpl->assign("error_no_password",1);
  $errorFlag = true;
}

$email = $_POST["email"];
if (empty($email)) {
  $tpl->assign("error_no_email",1);
  $errorFlag = true;
}

$job = $_POST["job"];

if (!isset($_POST["gender"])) {
  $tpl->assign("error_no_gender",1);
  $errorFlag = true;
  $gender = null;
} else {
  $gender 	= $_POST["gender"];
}

if (!isset($_POST["hobby"])) {
  $tpl->assign("error_no_hobby",1);
  $errorFlag = true;
  $hobbies = array();
} else {
  $hobbies 	= $_POST["hobby"];
}
$comment 	= $_POST["comment"];

//
// テンプレート変数へのアサイン
//
$tpl->assign("errorFlag", $errorFlag);
$tpl->assign("jobList", array(1=>"会社員", "学生", "主婦", 99=>"その他"));
$tpl->assign("hobbyList", array(1=>"音楽", "読書", "映画", "パソコン"));
$tpl->assign("userID", $userID);
$tpl->assign("password", $password);
$tpl->assign("email", $email);
$tpl->assign("gender", $gender);
$tpl->assign("job", $job);
$tpl->assign("hobby", $hobbies);
$tpl->assign("comment", $comment);

//
// テンプレートを指定して出力
//
$tpl->display("regist_confirm.tpl");
?>

