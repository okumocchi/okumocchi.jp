<html>
<head>
<title>会員登録</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
</head>
<body>
<h1>入力内容確認</h1>
以下の内容で正しければ[送信]ボタンをクリックしてください。<br>
修正する場合は[戻る]ボタンをクリックしてください。<br>
<?php
// 変換用配列を用意
$gender_list = array(0=>"", "m"=>"男", "f"=>"女");
$address_list = array(1=>"東京都", 2=>"神奈川県", 3=>"千葉県", 4=>"埼玉県");
$course_list = array(1=>"PHPベーシック", 2=>"PHPマスター", 3=>"システム開発演習", 4=>"資格対策");

// 入力されたデータの取得
$name     = $_POST["name"];
$email    = $_POST["email"];
$user_id  = $_POST["user_id"];
$password = $_POST["password"];
if (isset($_POST["gender"])) {
    $gender   = $_POST["gender"];
} else {
	$gender = 0;
}
$address  = $_POST["address"];
if (isset($_POST["course"])) {
    $course   = $_POST["course"];
} else {
	$course = array(); //空の配列で初期化
}
$pr       = $_POST["pr"];

//
// トリミング
//
$name = trim($name);
//$name = trim($name,"　"); // ひらがななどが全角スペースの後に来た場合に不具合発生
$user_id = trim($user_id);
$password = trim($password);

//
// 未入力チェック
//
if (empty($name)) {
	echo "<div style='color:red'>氏名が入力されていません</div>";
}
if (empty($email)) {
	echo "<div style='color:red'>メールアドレスが入力されていません</div>";
}
if (empty($user_id)) {
	echo "<div style='color:red'>ユーザIDが入力されていません</div>";
}
if (empty($password)) {
	echo "<div style='color:red'>パスワードが入力されていません</div>";
}
if (empty($gender)) {
	echo "<div style='color:red'>性別が選択されていません</div>";
}
if (empty($course)) {
	echo "<div style='color:red'>コースが選択されていません</div>";
}
if (empty($pr)) {
	echo "<div style='color:red'>自己PRが入力されていません</div>";
}

//
// 長さチェック
//
if (strlen($user_id) > 10 ) {
	echo "<div style='color:red'>ユーザIDは10文字以下で入力してください</div>";
}
if (strlen($password) < 6 ||  strlen($password) > 20) {
	echo "<div style='color:red'>パスワードは6文字以上20文字以下で入力してください</div>";
}

//
// 書式チェック
//
if (!preg_match('|^[a-z0-9_.~?/-]+@([a-z0-9-]+\.)+[a-z0-9-]+$|i', $email)) {
	echo "<div style='color:red'>正しいメールアドレスではありません</div>";
}
if (!preg_match('/^\w+$/', $user_id)) {
	echo "<div style='color:red'>ユーザIDに使用できない文字が含まれています</div>";
}
if (!preg_match('/^[!-~]+$/', $password)) {
	echo "<div style='color:red'>パスワードに使用できない文字が含まれています</div>";
}

?>

<table border="1">
<tr><th>氏名</th><td><?php echo $name ?></td></tr>
<tr><th>メールアドレス</th><td><?php echo $email ?></td></tr>
<tr><th>ユーザID</th><td><?php echo $user_id ?></td></tr>
<tr><th>パスワード</th><td><?php echo $password ?></td></tr>
<tr><th>性別</th><td><?php echo $gender_list[$gender] ?></td></tr>
<tr><th>住所</th><td><?php echo $address_list[$address] ?></td></tr>
<tr><th>コース</th><td>
<?php
foreach ($course as $code) {
    echo $course_list[$code] . "<br>";
}
?>
</td></tr>
<tr><th>自己PR</th><td><?php echo nl2br($pr) ?></td></tr>
</table>

<form action="complete.php" method="POST">
<input type="submit" value="送信">
<input type="button" value="戻る" onClick="javascript:history.back()">
</form>
</body>
