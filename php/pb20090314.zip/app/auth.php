<?php
echo '$_GETの内容<br>';
var_dump($_GET);
echo "<br>";
echo '$_POSTの内容<br>';
echo "ユーザIDは " . $_POST["user_id"] . "ですね。";

?>

