<?php
$a = array("apple" => 100, "peach" => 150, "mango" => 800);
?>
<table border="1">
<tr><th>キー</th><th>値</th></tr>
<tr><td>apple</td><td><?php echo $a["apple"]; ?></td></tr>
<tr><td>peach</td><td><?php echo $a["peach"]; ?></td></tr>
<tr><td>mango</td><td><?php echo $a["mango"]; ?></td></tr>
</table>

<!-- 別解 -->
<?php
echo "<table border='1'>";
echo "<tr><th>キー</th><th>値</th></tr>";
$key = "apple";
echo "<tr><td>$key</td><td>{$a[$key]}</td></tr>";
$key = "peach";
echo "<tr><td>$key</td><td>{$a[$key]}</td></tr>";
$key = "mango";
echo "<tr><td>$key</td><td>{$a[$key]}</td></tr>";
echo "</table>";
}
?>
