<?php
$a = array("apple", "peach", "mango");

echo "There is a <font color='red'>{$a[2]}</font> on the table";

// ���ʉ���
// echo "There is a <font color='red'>" . $a[2] . "</font> on the table";
// echo "There is a <span style='color:red'>{$a[2]}</span> on the table";
?>

