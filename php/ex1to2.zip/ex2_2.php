<?php
$a = array(100, 3 => 150, 800);

// 次の行をforeach文を使って記述
//$sum = $a[0] + $a[3] + $a[4];

foreach ($a as $v) {
    $sum += $v;
}

echo "合計は{$sum}円です。";
?>
