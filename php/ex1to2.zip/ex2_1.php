<?php
$a = array("apple" => 100, "peach" => 150, "mango" => 800);

// <table>タグと見出し行の出力は繰り返さない
echo "<table>";
echo "<tr><th>キー</th><th>値</th></tr>";

// データ行を繰り返し出力
foreach ($a as $k => $v) {
    echo "<tr><td>$k</td><td>$v</td></tr>";
}

echo "</table>
?>


