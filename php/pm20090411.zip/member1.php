<?php
//
// オブジェクト指向プログラミングの例
// まずオブジェクトの型であるクラスを定義し、必要に応じてnew演算子を用いてオブジェクト（インスタンス）
// を生成する

class Member {
  public $name;
  public $birthday;
  public function getAge() {
	$age = floor((date("Ymd") - date("Ymd", strtotime($this->birthday))) /10000);
	return $age;
  }
}

// 1つ目のオブジェクトを作成
$m1 = new Member;
$m1->name = "鈴木一朗";
$m1->birthday = "1973-10-22";
echo $m1->name . "さんは現在" . $m1->getAge() . "歳です<br>";

// 2つ目のオブジェクトを作成
$m2 = new Member;
$m2->name = "浅田真央";
$m2->birthday = "1990-9-25";
echo $m2->name . "さんは現在" . $m2->getAge() . "歳です<br>";

?>

