<?php
//
// オブジェクト指向でないプログラムの例
// ある人の情報がプログラム中にばらばらに存在しているため、わかりにくく、またミスを犯しやすい
//

$name2 = "石川遼";
$name1 = "鈴木一朗";
$birthday1 = "1991-10-22";
$birthday2 = "1991-9-17";
echo $name1 . "さんは現在" . getAge($birthday1) . "歳です<br>";
echo $name2 . "さんは現在" . getAge($birthday1) . "歳です<br>";


// 生年月日を文字列で渡すと、現在何歳かを返す関数
function getAge($birthday) {
	$age = floor((date("Ymd") - date("Ymd", strtotime($birthday))) /10000);
	return $age;
}
?>

