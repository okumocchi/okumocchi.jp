<?php
//
// クラスによるカプセル化の例
// 重要なプロパティについてはアクセス指定をprivateに設定する。
// そうすれば外部から不用意にアクセスされることを防ぎ、データの保全性が高まる。
//
class Member {
  private $name;
  private $birthday;
  public function getAge() {
	$age = floor((date("Ymd") - date("Ymd", strtotime($this->birthday))) /10000);
	return $age;
  }
  
  //
  // セッターの定義（プロパティに値をセットするためのメソッド）
  //
  public function setName($name) {
	  $this->name = $name;
  }
  public function setBirthday($birthday) {
    $this->birthday = $birthday;
  }
  
  //
  // ゲッターの定義（プロパティの値を取得するためのメソッド）
  //
  public function getName() {
    return $this->name;
  }
}

$m1 = new Member;
$m1->setName("鈴木一朗");       // $nameや$birthdayプロパティがprivateと設定されているので
$m1->setBirthday("1973-10-22"); // member1.phpのように直接代入したり参照したりはできない。
echo $m1->getName() . "さんは現在" . $m1->getAge() . "歳です<br>";

$m2 = new Member;
$m2->setName("浅田真央");
$m2->setBirthday("1990-9-25");
echo $m2->getName() . "さんは現在" . $m2->getAge() . "歳です<br>";
?>

