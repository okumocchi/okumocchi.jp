<?php
  $link = mysql_connect('localhost', 'root', 'himitu');
  if(!$link) {
	  die("MySQLへの接続に失敗しました。");
  } else {
	  echo "MySQLへの接続に成功しました。";
  }
  $conn = mysql_select_db('sample', $link);
  if(!$conn) {
	  die("データベースに接続できません。");
  }
  
  // 	
  $sql = "SELECT schedule.code, course.title, course.price, staff.name,
  schedule.start_date, schedule.end_date
  FROM schedule 
  JOIN course ON schedule.course=course.code
  JOIN staff ON schedule.staff=staff.code
  ORDER BY schedule.start_date";
    
  $result = mysql_query($sql, $link);
  if (!$result) {
	  echo "SQL文の発行に失敗しました。<br>";
	  die(mysql_error($link));
  }

  $rows = mysql_num_rows($result);
  if($rows < 1) {
	  die("データが存在しませんでした");
  }
?>
<html>
<body>
<table border="1">
<tr><td>コースコード</td><td>コース名</td><td>講師</td><td>開始日</td><td>終了日</td></tr>
<?php
  while ($data = mysql_fetch_assoc($result)) {
?>
	<tr>
	<td><?php echo $data["code"]; ?></td>
	<td><?php echo $data["title"]; ?></td>
	<td><?php echo $data["name"]; ?></td>
	<td><?php echo $data["start_date"]; ?></td>
	<td><?php echo $data["end_date"]; ?></td>
	</tr>
<?php
  }
?>
</table>
</body>
</html>

