<?php
require_once "/usr/share/Smarty/libs/Smarty.class.php";

$tpl = new Smarty;

$name = "山田太郎";
$gender = 1;

// １つずつアサイン
$tpl->assign("name", $name);
$tpl->assign("gender", $gender);

// まとめてアサイン
$vals = array("name2"=>"Taro", "gender2"=>1);
$tpl->assign($vals);

// 配列をアサイン
$arr = array("Yoko", 2);
$tpl->assign("data", $arr);

// 連想配列をアサイン
$arr2 = array("name"=>"Hiroshi", "gender"=>1);
$tpl->assign("data2", $arr2);

// ２次元配列をアサイン
// （DBから値を取得したときはこのケースが多い）
$arr3 = array(
  array("name"=>"Kyoko", "gender"=>2),
  array("name"=>"Hiromi", "gender"=>0),
  array("name"=>"Takeshi", "gender"=>1),
  array("name"=>"Mei", "gender"=>2)
);
$tpl->assign("data3", $arr3);
$tpl->display("smarty.tpl");
?>
