--
-- コースマスタ
--
CREATE TABLE course (
	id INT PRIMARY KEY,
	name VARCHAR(100)
);

INSERT INTO course VALUES(1, "PHPベーシック");
INSERT INTO course VALUES(2, "PHPマスター");
INSERT INTO course VALUES(3, "システム開発演習");
INSERT INTO course VALUES(4, "資格対策");

--
-- 履修コース
--
CREATE TABLE take_course (
	member_id INT REFERENCES members(id),
	course_id INT REFERENCES course(id),
	PRIMARY KEY(member_id, course_id)
);

