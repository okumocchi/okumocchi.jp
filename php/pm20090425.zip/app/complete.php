<html>
<head>
<title>会員登録</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
</head>
<sdfghjkbody>
<?php
// 登録情報をファイルに書き込む
//
$name     = $_POST["name"];
$email    = $_POST["email"];
$user_id  = $_POST["user_id"];
$password = $_POST["password"];
$gender   = $_POST["gender"];
$address  = $_POST["address"];
$course   = $_POST["course"];
$pr       = $_POST["pr"];

// DB接続
require "/usr/share/pear/DB.php";
$dsn = "mysql://root:himitu@localhost/myapp";
$cn = DB::connect($dsn);
if (DB::isError($cn)) {
	die("データベースに接続できません");
}
// 会員テーブルへの登録
$sql = "INSERT INTO members(name,email,user_id,password,gender,address,pr)"
  . " VALUES('$name', '$email', '$user_id', '$password',"
  . " '$gender', $address, '$pr')";
$ret = $cn->query($sql);
if ($ret != DB_OK) {
	echo $sql;
	echo DB::errorMessage($ret);
	die ("データの登録に失敗しました");
}

// 以下、追加 ////////////////////////////////////////
// 上で登録したレコードのID列の値を得る
$member_id = mysql_insert_id(); 

// 履修コーステーブルへの登録
foreach ($course as $course_id) {
  $sql = "INSERT INTO take_course VALUES($member_id, $course_id)";
  $ret = $cn->query($sql);
  if ($ret != DB_OK) {
	echo $sql;
	echo DB::errorMessage($ret);
	die ("データの登録に失敗しました");
  }
}
// ここまで ////////////////////////////////////////

/*
$file_name = "members.dat";
$fp = fopen ($file_name, "a");
if (!$fp) {
	die ("ファイルのオープンに失敗しました");
}
fputs ($fp, "$name,$email,$user_id,$password,$gender,$address,$course,$pr\n");
fclose($fp);
*/

$subject = "会員登録の確認";
$body = <<<EOF
{$name}様

この度は当サイトへの登録ありがとうございました。
登録情報は以下の通りです。

ユーザID：$user_id;
パスワード：$password;
EOF;

$from = "From:phpbasic@la.jp";
mb_language("ja");
mb_internal_encoding("UTF-8");
if(!mb_send_mail($email, $subject, $body, $from)) {
	die("メールの送信に失敗しました");
}


?>
<h1>登録完了</h1>
会員登録を完了しました。トップページからユーザIDとパスワードでログインしてください。<br>
<a href="index.html">トップページへ</a>
</body>


