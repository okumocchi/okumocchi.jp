<?php
require_once "/usr/share/Smarty/libs/Smarty.class.php";
$tpl = new Smarty;
//
// 変換用配列を用意
//
$gender_list = array(0=>"", "m"=>"男", "f"=>"女");
$address_list = array(1=>"東京都", 2=>"神奈川県", 3=>"千葉県", 4=>"埼玉県");
$course_list = array(1=>"PHPベーシック", 2=>"PHPマスター", 3=>"システム開発演習", 4=>"資格対策");

//
// 入力されたデータの取得
//
$name     = $_POST["name"];
$email    = $_POST["email"];
$user_id  = $_POST["user_id"];
$password = $_POST["password"];
if (isset($_POST["gender"])) {
    $gender   = $_POST["gender"];
} else {
	$gender = 0;
}
$address  = $_POST["address"];
if (isset($_POST["course"])) {
    $course   = $_POST["course"];
} else {
	$course = array(); //空の配列で初期化
}
$pr       = $_POST["pr"];

//
// トリミング
//
//$name = trim($name);
//$name = trim($name,"　"); // ひらがななどが全角スペースの後に来た場合に不具合発生

$name = preg_replace('/^[\s　]*(.*?)[\s　]*$/u', '$1', $name);
$user_id = preg_replace('/^[\s　]*(.*?)[\s　]*$/u', '$1', $user_id);
$password = preg_replace('/^[\s　]*(.*?)[\s　]*$/u', '$1', $password);

//
// 入力値チェック
//
// $error_flag = false; // エラーフラグ

// PHPファイルでは具体的なメッセージを記述せず、エラーコードをテンプレートに渡す。
// $errors配列に１つでも要素が格納されていればエラーがあったことになるので、エラーフラグを兼ねる。
$errors = array();
// 氏名
if (empty($name)) {
	$errors[] = "no_name";
}
// メールアドレス
if (empty($email)) {
	$errors[] = "no_email";
} elseif (!preg_match('|^[a-z0-9_.~?/-]+@([a-z0-9-]+\.)+[a-z0-9-]+$|i', $email)) {
	$errors[] = "bad_email";
}
// ユーザID
if (empty($user_id)) {
	$errors[] = "no_user_id";
} elseif (strlen($user_id) > 10 ) {
	$errors[] = "badlen_user_id";
} elseif (!preg_match('/^\w+$/', $user_id)) {
	$errors[] = "bad_user_id";
}
//パスワード
if (empty($password)) {
	$errors[] = "no_password";
} elseif (strlen($password) < 6 ||  strlen($password) > 20) {
	$errors[] = "badlen_password";
} elseif (!preg_match('/^[!-~]+$/', $password)) {
	$errors[] = "bad_password";
}
// 性別
if (empty($gender)) {
	$errors[] = "no_gender";
}
// コース
if (empty($course)) {
	$errors[] = "no_course";
}
// 自己PR
if (empty($pr)) {
	$errors[] = "no_pr";
}


//
// テンプレートに渡すデータ
//
$tpl->assign("name", $name);
$tpl->assign("email", $email);
$tpl->assign("user_id", $user_id);
$tpl->assign("password", $password);
$tpl->assign("gender", $gender_list[$gender]);
$tpl->assign("gender_id", $gender);
$tpl->assign("address", $address_list[$address]);
$tpl->assign("address_id", $address);
$tpl->assign("course", $course); 
$tpl->assign("pr", $pr); 

//
// テンプレートファイルを読み込み、HTMLを出力
// エラーの有無によって、テンプレートファイルを分ける
//
if ($errors) {
  // 入力エラーあり
  // エラー情報と選択コースのコードをキーとした配列をテンプレートに渡す
  $tpl->assign("errors", $errors);
  $course_id = array();
  foreach ($course as $code) {
    $course_id[$code] = true;
  }
  $tpl->assign("course_id", $course_id);
  
  $tpl->display("input.tpl");
} else {
  // 入力エラーなし
  // コース名の配列をテンプレートに渡す
  $courses = array();
  foreach ($course as $code) {
    $courses[] = $course_list[$code];
  }
  $tpl->assign("courses", $courses); 
  $tpl->assign("pr", $pr);

  $tpl->display("confirm.tpl");
}
?>
