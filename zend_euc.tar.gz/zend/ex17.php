<?php
	$v = array("a", "e", "i", "o", "u", "A", "E", "I", "O", "U");
	print(str_replace($v, "", "Hello World of PHP"));
?>
