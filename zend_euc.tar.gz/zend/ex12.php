<?php
	$arr = array( 10, 100, 1000, 10000, 100000);
	foreach (array_keys($arr) as $v) {
		print $v . ",";
	}
?>
