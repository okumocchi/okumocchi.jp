<?php
	$a = 0;
	$b = "";
	
	if ($a == false) {
		print "FALSE<br>";
	}
	if ($b == false) {
		print "FALSE<br>";
	}
	if ($a === false) {
		print "FALSE<br>";
	}
	if ($b === false) {
		print "FALSE<br>";
	}
?>
