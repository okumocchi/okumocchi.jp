<?php
	for ($i = 0; $i < 3; $i++) {
		for( $j = 0; $j < 3; $j++) {
			if ($i > $j) {
				// print "$i=" . $i . ",$j=" . $j . "\n";
				print '$i=' . $i . ',$j=' . $j . "<br>\n";
			}
		}
	}
?>