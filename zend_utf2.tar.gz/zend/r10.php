﻿<?php
	function f(&$val)
	{
		return $val + 1;
	}

	$a = 1;
	f($a);
	echo $a;
?>
