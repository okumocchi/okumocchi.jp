<?php
	class MyClass1 {
		function __construct() {
			echo "1C";
		}
		function __destruct() {
			echo "1D";
		}
	}
	
	class MyClass2 {
		function __construct() {
			echo "2C";
		}
		function __destruct() {
			echo "2D";
		}
		function method2() {
			echo "2M";
		}
	}
	
	$obj1 = new MyClass1;
	$obj2 = new MyClass2;
	$obj1 = null;
	$obj2->method2();
?>
