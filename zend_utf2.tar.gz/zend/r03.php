<?php
	$s = "/abc/def/value";
	$ss = substr($s, strrpos($s, '/'));
	
	echo $ss;
?>
