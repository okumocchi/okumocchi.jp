<?php
	$dom = new DOMDocument();
	$dom->load("sample.xml");
	
	$member = $dom->createElement("member");
	
	$name = $dom->createElement("name", "Hanako Sato");
	$age = $dom->createElement("age", "20");
	$gender = $dom->createElement("gender", "female");
	$member->appendChild($name);
	$member->appendChild($age);
	$member->appendChild($gender);
	
	$dom->documentElement->appendChild($member);
	
	echo $dom->saveXML();
?>
