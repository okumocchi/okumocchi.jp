<?php
	class MyFactory {
		const CSV = 1;
		const DB = 2;
		const XML = 3;
		
		public static function getDatasource($type) {
			switch($type) {
				case self::CSV:
					return new CSVDatasource;
				case self::DB:
					return new DBDatasource;
				case self::XML:
					return new XMLDatasource;
			}
		}
	}
	abstract class MyDatasource {
		abstract function show();
	}
	
	class CSVDatasource extends MyDatasource {
		function show() {
			echo "CSV!!<br>";
		}
	}

	class DBDatasource extends MyDatasource {
		function show() {
			echo "DBV!!<br>";
		}
	}

	class XMLDatasource extends MyDatasource {
		function show() {
			echo "XML!!<br>";
		}
	}

	$obj[] = MyFactory::getDatasource(MyFactory::CSV);
	$obj[] = MyFactory::getDatasource(MyFactory::DB);
	$obj[] = MyFactory::getDatasource(MyFactory::XML);
	
	foreach ($obj as $o) {
		$o->show();
	}
?>
