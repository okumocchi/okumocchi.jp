<?php
	$a = array(true, 0=>1, false=>2);
	
	var_dump($a);
?>
