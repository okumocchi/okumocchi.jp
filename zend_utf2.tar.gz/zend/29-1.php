<?php
	class MyException1 extends Exception{}
	class MyException2 extends Exception{}
	
	try {
		throw new MyException1("An unknown error.");
	}
	catch (MyException2 $e) {
		echo "MyException2::" . $e->getMessage();
	}
	catch (MyException1 $e) {
		echo "MyException1::" . $e->getMessage();
	}
	catch (Exception $e) {
		echo "Exception::" . $e->getMessage();
	}

	echo "<br>";

	try {
		throw new MyException1("An unknown error.");
	}
	catch (Exception $e) {
		echo "Exception::" . $e->getMessage();
	}
	catch (MyException1 $e) {
		echo "MyException1::" . $e->getMessage();
	}
	catch (MyException2 $e) {
		echo "MyException2::" . $e->getMessage();
	}

?>
