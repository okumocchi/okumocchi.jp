﻿<?php
	function __autoload($classname) {
		if ($classname == "MyClass") {
			require_once("MyClass.php");
			echo "MyClass.phpを自動的にロードしました。<br>";
		}
	}
	
	$obj = new MyClass;
	$obj->show();
?>
