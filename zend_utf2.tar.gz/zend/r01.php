<?php
	$s = "mail:mn";
	$pos = strpos($s, 'm', 2);
	
	echo $pos;
?>
