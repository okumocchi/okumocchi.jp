<?php
	class MyClass {
		function show() {
			echo "MyClass!!<br>";
		}
	}
?>
