<?php
	$dom = new DOMDocument();
	$dom->load("sample.xml");
	$xpath = new DOMXPath($dom);
	$nlist = $xpath->query("//addressbook/member/name");
	foreach ($nlist as $node) {
		echo $node->nodeValue . "<br>";
	}
?>
