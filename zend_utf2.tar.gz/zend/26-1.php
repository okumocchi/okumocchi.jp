<?php
	class MyClass {
		public static $bar = "bat";
		public static function baz() {
			echo "Hello<br>";
		}
	}
	
	$obj = new MyClass;
	$obj->baz();	// MyClass::baz(); �ł�OK
	echo $obj->bar . "<br>";
	echo MyClass::$bar . "<br>";
?>
