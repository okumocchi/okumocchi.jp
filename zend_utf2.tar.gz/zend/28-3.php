﻿<?php
	abstract class MyAbClass {
		public $name;
		function showName() {
			echo $this->name . "<br>";
		}
		abstract function speak();
	}
	
	class MyDog extends MyAbClass {
		function speak() {
			echo "ワンワン<br>";
		}
	}
	
	class MyCat extends MyAbClass {
		function speak() {
			echo "ニャー<br>";
		}
	}
	
	$obj[0] = new MyDog;
	$obj[0]->name = "Taro";
	$obj[1] = new MyCat;
	$obj[1]->name = "Tama";
		
	foreach ($obj as $o) {
		$o->showName();
		$o->speak();
	}	
?>
