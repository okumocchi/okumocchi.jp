﻿<?php
	abstract class Animal {
		public function walk() {
			echo "歩いた<br>";
		}
		abstract public function cry(); 
	}

	class Dog extends Animal {
		public function cry() {
			echo "ワンワン<br>";
		}
	}

	$d = new Dog;
	$d->walk();
	$d->cry();
?>
