<?php
	abstract class MyAbClass {
		private $id;
		public abstract function insert();
		public abstract function update();
		public function save() {
			if (!is_null($this->id)) {
				$this->update();
			} else {
				$this->insert();
				$this->id = 100;
			}
		}
	}
	
	class MyClass extends MyAbClass {
		public function insert() {
			echo "call insert()<br>";
		}
		public function update() {
			echo "call update()<br>";
		}
	}
	
	$obj = new MyClass;
	$obj->save();
	$obj->save();
?>
