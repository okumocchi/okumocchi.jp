<?php
	class MyClass {
		function method1() {
			echo "Hello!<br>";
		}
	}
	
	MyClass::method1();
?>
