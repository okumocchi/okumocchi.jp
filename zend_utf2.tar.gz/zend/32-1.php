<?php
	class MyClass {
		private static $_singleton;
		private function __construct(){}
		public static function getInstance() {
			if (is_null(self::$_singleton)) {
				self::$_singleton = new MyClass;
			}
			return self::$_singleton;
		}
	}
	
	$obj1 = MyClass::getInstance();
	$obj2 = MyClass::getInstance();
	echo (int)($obj1 == $obj2);
?>
