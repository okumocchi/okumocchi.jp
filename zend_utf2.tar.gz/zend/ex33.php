<?php
	function methodFoo($num) {
		if (!is_numeric($num)) {
			throw new Exception("Not a number.");
		}
		if ($num < 0) {
			throw new Exception("Negative number.");
		}
		echo "OK";
	}

	try {
		methodFoo(10);
		methodFoo("Hello");
		methodFoo(-50);
	}
	catch (Exception $e) {
		echo "Exception!!";
	}

?>
