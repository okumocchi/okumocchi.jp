﻿<?php
	class Cart {
		private $items;
		private $item;
		
		public function __construct() {
			$this->items = 0;
			$this->item = array();
		}
		
		public function add($name) {
			$this->items++;
			$this->item[] = $name;
		}
		public function confirm() {
			echo "{$this->items}個の商品が入っています<br>";
			foreach ($this->item as $name) {
				echo "{$name}<br>";
			}
		} 
		
	}
	
	$c1 = new Cart;
	$c1->add("Pen");
	$c1->confirm();
	$c1->add("Note");
	$c1->confirm();
?>
