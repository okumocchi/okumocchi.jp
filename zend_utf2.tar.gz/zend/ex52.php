<?php
	$dom = new DOMDocument();
	$dom->load("ex52.xml");
	
	$xpath = new DOMXPath($dom);
	$members = $xpath->query("//addressbook/member");
	
	foreach ($members as $member) {
		$member->appendChild($dom->createElement("memo", ""));
	}
			
	echo $dom->saveXML();
?>
