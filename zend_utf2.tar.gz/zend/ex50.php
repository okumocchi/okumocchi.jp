<?php
	echo getservbyname('ftp', 'udp');
?>
