﻿<?php
class A {
	public $p = 1;
}

function f(A $a) {
	if ($a) {
		echo $a->p;
	}
}

f(NULL);
?>
