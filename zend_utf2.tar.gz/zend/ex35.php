<?php
	class MyFactory {
		const DB = 1;
		const XML = 2;
		
		public static function getDatasource($type) {
			switch($type) {
				case self::DB:
					return new DBDatasource;
				case self::XML:
					return new XMLDatasource;
				default:
					throw new Exception("Unknown option.<br>");
			}
		}
	}
	abstract class MyDatasource {
		abstract public static function getInstance();
	}
	
	class DBDatasource extends MyDatasource {
		private static $instance;
		private function __constract(){}
		public static function getInstance() {
			if(is_null(self::$instance)) {
				self::$instance = new DBDatasource;
			}
			return self::$instance;
		}
	}

	class XMLDatasource extends MyDatasource {
		private static $instance;
		private function __constract(){}
		public static function getInstance() {
			if(is_null(self::$instance)) {
				self::$instance = new XMLDatasource;
			}
			return self::$instance;
		}
	}
	
	$obj1 = MyFactory::getDatasource(MyFactory::DB);
	$obj2 = MyFactory::getDatasource(MyFactory::DB);
	$obj3 = MyFactory::getDatasource(MyFactory::XML);
	echo (int)($obj1 == $obj2);
	echo (int)($obj2 == $obj3);
?>	
