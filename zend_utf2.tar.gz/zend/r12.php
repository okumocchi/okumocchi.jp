<?php
	preg_match('/^(([0-9]{1,2})[a-z]+)(?:\s)\S+\s(?<=20)[0-9]/', "21st march 2008" , $matches);
//	preg_match('/^(([0-9]{1,2})[a-z]+)(?:\s)\S+\s(?=200[0-9])$/', "21st march 2008" , $matches);
	var_dump($matches);
?>
