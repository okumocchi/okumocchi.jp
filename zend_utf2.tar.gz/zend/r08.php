﻿<?php
	function fibonacchi(&$a = 0, &$b = 1) 
	{
		$c = $a + $b;
		$a = $b;
		$b = $c;
		return $c;
	}

	$s="";
	for ($i = 0; $i < 10; $i++) {
		$s .= fibonacchi() . ",";
	}
	
	echo $s;
?>
