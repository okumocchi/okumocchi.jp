<?php
	$xml = simplexml_load_file("sample.xml");
	
	$members = $xml->xpath("//addressbook/member");
	foreach ($members as $member) {
		$member->addChild("memo", "");
	}
	
	echo $xml->asXML();
?>
