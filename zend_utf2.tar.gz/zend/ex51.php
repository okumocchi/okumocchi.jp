<?php
	$dom = new DOMDocument();
	$dom->load("ex51.xml");
	$xpath = new DOMXPath($dom);
	$nlist = $xpath->query("//memberlist/membergroup/member/name");
	foreach ($nlist as $node) {
		echo $node->nodeValue . "<br>";
	}
?>
