﻿<?php
	$ret = foo();
	echo "戻り値は\"{$ret}\"<br>";
	$ret = foo("foo");
	echo "戻り値は\"{$ret}\"<br>";
	$ret = foo("abc");
	echo "戻り値は\"{$ret}\"<br>";
	
	function foo($x = "no parameter") {
		return $x == "foo" ? "bar" : $x;
	}
?>
