﻿<?php
	class Animal {
		public function walk() {
			echo "歩いた<br>";
		}
		public function cry() {
		 echo "???<br>";
		}
	}

	$a = new Animal;
	$a->walk();
	$a->cry();
?>
