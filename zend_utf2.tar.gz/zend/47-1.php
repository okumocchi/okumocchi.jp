<?php
	$dom = new DOMDocument();
	$dom->load("sample.xml");
	echo $dom->saveXML();
?>
