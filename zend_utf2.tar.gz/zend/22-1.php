<?php
	class MyClass1 {
		function __construct() {
			echo "MyClass1::__construct()<br>";
		}
		function __destruct() {
			echo "MyClass1::__destruct()<br>";
		}
		function method1() {
			echo "MyClass1::method1()<br>";
		}
	}
	
	class MyClass2 {
		private function __construct() {
			echo "MyClass2::__construct()<br>";
		}
	}
	
	$obj1 = new MyClass1;
	$obj1->method1();
	$obj1 = null;
	
	$obj2 = new MyClass2;
?>
