﻿<?php
	abstract class Animal {
		public function walk() {
			echo "歩きます<br>";
		}
		abstract public function cry(); 
	}

	class Dog extends Animal {
		public function cry() {
			echo "ワンワン<br>";
		}
	}

	abstract class Bird extends Animal{
		public function fly() {
			echo "飛びます<br>";
		}
	}
	
	class Crow extends Bird {
		public function cry() {
			echo "カァ～<br>";
		}
	}
	
	class Bat extends Animal {
		public function cry() {
			echo "キキキ<br>";
		}
		public function fly() {
			echo "飛びます<br>";
		}
	}

	function flyAll(Bird $o) {
		$o->fly();
	}

	
	$d = new Dog;
	$d->walk();
	$d->cry();
	
	$c = new Crow;
	$c->fly();
	$c->cry();
	
	$b = new Bat;
	
	flyAll($c);
	flyAll($b);
	
?>
