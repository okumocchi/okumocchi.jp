﻿<?php
	$to = "okumocchi@yahoo.co.jp";
	$subject = "Test php sending";
	$body = "こんにちは、このメールは無事に見ることができましたか？";
	mb_language("ja");
	if (mb_send_mail($to, $subject, $body)) {
		echo "メールの送信に成功しました。";
	} else {
		echo "メールの送信に失敗しました。";
	}
?>
