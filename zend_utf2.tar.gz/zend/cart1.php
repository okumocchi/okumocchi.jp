<?php
	class Cart {
		private $items;
		private $item;
		
		public function __construct() {
			$this->items = 0;
			$this->item = array();
		}
		
		public function add($name) {
			$this->items++;
			$this->item[] = $name;
		}
		
	}
	
	$c1 = new Cart;
	$c1->add("Pen");
?>
